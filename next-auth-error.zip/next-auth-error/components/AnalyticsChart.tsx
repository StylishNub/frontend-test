"use client";

import React from "react";
import { ArcElement, Chart as ChartJS, Legend, Tooltip } from "chart.js";
import { Doughnut } from "react-chartjs-2";

ChartJS.register(ArcElement, Tooltip, Legend);

export default function AnalyticsChart() {
  // Data untuk Donut Chart
  const data = {
    labels: ["Pesan Masuk", "Pesan Keluar", "Pesan Gagal"],
    datasets: [
      {
        label: "Jumlah Pesan",
        data: [45, 23, 8], // Data sesuai dengan ringkasan hari ini
        backgroundColor: [
          "rgba(51, 102, 255, 1)", // Warna solid
          "rgba(79, 190, 171, 1)",
          "rgba(243, 245, 248, 1)",
        ],
        borderColor: [
          "rgba(51, 102, 255, 1)", // Warna solid
          "rgba(79, 190, 171, 1)",
          "rgba(243, 245, 248, 1)",
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    plugins: {
      legend: {
        display: false, // Menonaktifkan keterangan
      },
      tooltip: {
        callbacks: {
          label: function (context: any) {
            return `${context.label}: ${context.raw}`; // Menampilkan label dan nilai saat tooltip muncul
          },
        },
      },
    },
  };

  return (
    <div className="bg-white shadow-sm rounded-lg p-4 sm:w-full md:w-[300px] lg:w-[400px]">
      <h2 className="text-lg font-semibold mb-4">Analitik</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Statistik Pesan */}
        <div className="border lg:w-[348px] lg:h-[200px] text-center">
          <h3 className="font-medium text-gray-700">Ringkasan hari ini</h3>
          <span className="mt-2 text-sm text-gray-600">Pesan Masuk : 7</span>
          <span className="mt-2 text-sm text-gray-600">Pesan Keluar: 24</span>
          <span className="mt-2 text-sm text-gray-600">Pesan Gagal : 0</span>
        </div>
        {/* Grafik Analitik */}
        <div className="ml-[200px] w-full h-32 md:h-36 flex items-center justify-center border rounded-lg  md:w-[300px] lg:w-[700px] lg:h-[200px]">
          <Doughnut data={data} options={options} />
        </div>
      </div>
    </div>
  );
}
