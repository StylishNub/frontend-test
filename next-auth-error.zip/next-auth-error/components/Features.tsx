import { FEATURES } from '@/constants'
import Image from 'next/image'
import React from 'react'

const Features = () => {
  return (
    <section className="flex-col flexCenter overflow-hidden py-24 bg-[#ECF2FA]">
      <div className="max-container padding-container relative w-full flex justify-end">
        <div className="z-20 flex w-full flex-col lg:w-[60%]">
          <div className="relative">
            <h2 className="text-xl lg:text-4xl font-bold">
              Respond Faster with the Convenience of Auto Reply
            </h2>
            <h3 className="mt-6">
              Fowardin mempermudah Anda untuk memberikan respon cepat kepada
              pesan dari banyak kontak dan grup sekaligus. Dengan fitur Auto
              Reply kami, Anda dapat menjawab pertanyaan atau memberikan respon
              otomatis, menghemat waktu dan energi Anda. Tanggap lebih cepat
              dengan Fowardin.
            </h3>
          </div>
        </div>
      </div>
    </section>
  );
}

type FeatureItem = {
  title: string;
  icon: string;
  description: string;
}

const FeatureItem = ({ title, icon, description }: FeatureItem) => {
  return (
    <li className="flex w-full flex-1 flex-col items-start">
      <h2 className="bold-20 lg:bold-32 mt-5 capitalize">
        {title}
      </h2>
      <p className="regular-16 mt-5 bg-white/80 text-gray-30 lg:mt-[30px] lg:bg-none">
        {description}
      </p>
    </li>
  )
}

export default Features