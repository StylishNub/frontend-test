import React from "react";

const GetApp = () => {
  return (
    <section className="flexCenter w-full flex-col pb-[100px]">
      <div className="">
        <div className="z-20 flex w-full flex-1 flex-col items-center justify-center gap-6 mt-5">
          <h2 className="text-xl font-bold xl:max-w-[400px] text-center text-[#3366FF]">
            "One Step Closer to More Effective and"
            <br />
            <span className="block mt-2">Connected Communication!</span>
          </h2>

          {/* Buttons and Description */}
          <div className="flex flex-col items-center gap-4 mt-6 w-full text-center">
            <div className="flex flex-wrap justify-center gap-4 w-full">
              <button className="px-6 py-2 bg-[#3366FF] text-white font-semibold rounded-md">
                Bisnis dan Pemasaran
              </button>
              <button className="px-6 py-2 border border-[#3366FF] text-[#3366FF] font-semibold rounded-md">
                Komersial dan Penjualan
              </button>
              <button className="px-6 py-2 border border-[#3366FF] text-[#3366FF] font-semibold rounded-md">
                Organisasi Sosial
              </button>
            </div>
            <p className="regular-16 mt-4 text-justify w-full max-w-[800px] ">
              Bidang ini dapat memanfaatkan fitur Broadcast untuk mengirim
              promosi, pengumuman, dan informasi produk kepada pelanggan dalam
              jumlah besar secara efisien. Selain itu, fitur Campaign dapat
              membantu merencanakan dan menyampaikan pesan iklan dengan waktu
              yang tepat kepada target audiens yang sesuai.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GetApp;
