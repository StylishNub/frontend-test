declare module "@iconify/icons-mdi/*" {
  const content: any;
  export default content;
}
