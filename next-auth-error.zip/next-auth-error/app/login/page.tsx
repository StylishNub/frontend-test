// app/login/page.tsx
import Login from "@/components/Login";

export default function LoginPage() {
  return (
    <div>
      <Login />
    </div>
  );
}
