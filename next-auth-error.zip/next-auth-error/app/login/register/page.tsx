// app/login/register/page.tsx

import Register from "@/components/Register"; // Pastikan path sesuai

export default function RegisterPage() {
  return (
    <div>
      <Register />
    </div>
  );
}
