// app/layout.tsx
import { Inter } from "next/font/google";
import type { Metadata } from "next";
import Header from "@/components/header";
import HeaderMobile from "@/components/header-mobile";
import SideNav from "@/components/side-nav";
import MarginWidthWrapper from "@/components/margin-width-wrapper";
import PageWrapper from "@/components/page-wrapper";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import ClientSideAuth from "./client-side-auth";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Frontend-test",
  description: "Travel UI/UX App for Camping",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Periksa sesi pengguna dan arahkan jika tidak ada sesi
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect("/login");
    return null; // Hentikan rendering jika perlu redirect
  }

  return (
    <html lang="en">
      <body className={`bg-white ${inter.className}`}>
        <div className="flex">
          <SideNav />
          <main className="flex-1">
            <MarginWidthWrapper>
              <ClientSideAuth>
                <Header />
                <HeaderMobile />
                <PageWrapper>{children}</PageWrapper>
              </ClientSideAuth>
            </MarginWidthWrapper>
          </main>
        </div>
      </body>
    </html>
  );
}
